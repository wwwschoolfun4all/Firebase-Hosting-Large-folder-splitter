#!/usr/bin/env node
/**
 * firebase-chunk-deploy
 * Deploys big folders to Firebase Hosting one folder at a time, in size-capped chunks,
 * honoring ignore patterns, with retries and resume.
 *
 * Uses the Hosting REST API: create version -> populateFiles (per chunk) -> upload
 * missing hashes -> finalize -> release.
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { GoogleAuth } = require('google-auth-library');
const ignoreLib = require('ignore');

// ---------- args ----------
const args = process.argv.slice(2);
const opt = {
  dir: 'public', site: null, project: null, channel: 'live', chunkMb: 50, maxFiles: 500,
  concurrency: 5, ignoreFile: '.firebaseignore', config: 'firebase.json',
  state: '.chunk-deploy-state.json', dryRun: false, resume: false, message: null,
};
const help = `
Usage: node deploy.js --site <site-id> [options]

  --site <id>          Hosting site ID (required, usually your project ID)
  --dir <path>         Folder to deploy (default: public)
  --channel <name>     "live" (default) or an existing preview channel
  --chunk-mb <n>       Max raw MB per upload chunk (default 50)
  --max-files <n>      Max files per chunk (default 500)
  --concurrency <n>    Parallel uploads inside a chunk (default 5)
  --ignore <file>      Ignore file, gitignore syntax (default .firebaseignore)
  --config <file>      firebase.json to copy rewrites/redirects/headers from
  --resume             Reuse the unfinished version saved in the state file
  --dry-run            List folders/chunks without uploading
  --message <text>     Release message
Auth: run "gcloud auth application-default login" or set GOOGLE_APPLICATION_CREDENTIALS.
`;
for (let i = 0; i < args.length; i++) {
  const a = args[i];
  const next = () => args[++i];
  if (a === '--site') opt.site = next();
  else if (a === '--dir') opt.dir = next();
  else if (a === '--channel') opt.channel = next();
  else if (a === '--chunk-mb') opt.chunkMb = Number(next());
  else if (a === '--max-files') opt.maxFiles = Number(next());
  else if (a === '--concurrency') opt.concurrency = Number(next());
  else if (a === '--ignore') opt.ignoreFile = next();
  else if (a === '--config') opt.config = next();
  else if (a === '--resume') opt.resume = true;
  else if (a === '--dry-run') opt.dryRun = true;
  else if (a === '--message') opt.message = next();
  else if (a === '-h' || a === '--help') { console.log(help); process.exit(0); }
}
if (!opt.site) { console.log(help); process.exit(1); }

const API = 'https://firebasehosting.googleapis.com/v1beta1';
const mb = (n) => (n / 1048576).toFixed(1) + ' MB';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- auth + http with retry ----------
const auth = new GoogleAuth({ scopes: ['https://www.googleapis.com/auth/cloud-platform'] });
async function token() {
  const c = await auth.getClient();
  return (await c.getAccessToken()).token;
}
async function request(url, init = {}, tries = 5) {
  for (let attempt = 1; ; attempt++) {
    try {
      const res = await fetch(url, {
        ...init,
        headers: { Authorization: `Bearer ${await token()}`, ...(init.headers || {}) },
      });
      if (res.ok) return res;
      const body = await res.text();
      if (attempt < tries && (res.status === 429 || res.status >= 500)) {
        await sleep(1000 * 2 ** attempt);
        continue;
      }
      throw new Error(`${res.status} ${url}\n${body}`);
    } catch (e) {
      if (attempt >= tries || /^\d{3} /.test(e.message)) throw e;
      await sleep(1000 * 2 ** attempt); // network error: retry
    }
  }
}
const json = (method, url, body) =>
  request(url, { method, headers: { 'Content-Type': 'application/json' }, body: body && JSON.stringify(body) })
    .then((r) => r.json());

// ---------- scan with ignore ----------
const DEFAULT_IGNORES = ['.git', '.git/**', '**/node_modules/**', '**/.*', 'firebase-debug.log', 'firebase.json', '**/.DS_Store'];
function loadIgnore() {
  const ig = ignoreLib().add(DEFAULT_IGNORES);
  if (fs.existsSync(opt.ignoreFile)) {
    ig.add(fs.readFileSync(opt.ignoreFile, 'utf8'));
    console.log(`Ignore rules loaded from ${opt.ignoreFile}`);
  }
  return ig;
}
function walk(root, ig) {
  const out = [];
  (function rec(dir) {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, ent.name);
      const rel = path.relative(root, abs).split(path.sep).join('/');
      if (ig.ignores(ent.isDirectory() ? rel + '/' : rel)) continue;
      if (ent.isDirectory()) rec(abs);
      else if (ent.isFile()) out.push({ rel, abs, size: fs.statSync(abs).size });
    }
  })(root);
  return out;
}
function groupByFolder(files) {
  const groups = new Map();
  for (const f of files) {
    const top = f.rel.includes('/') ? f.rel.split('/')[0] : '(root files)';
    if (!groups.has(top)) groups.set(top, []);
    groups.get(top).push(f);
  }
  return [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0]));
}
function chunkFiles(files) {
  const chunks = []; let cur = []; let bytes = 0;
  for (const f of files) {
    if (cur.length && (bytes + f.size > opt.chunkMb * 1048576 || cur.length >= opt.maxFiles)) {
      chunks.push(cur); cur = []; bytes = 0;
    }
    cur.push(f); bytes += f.size;
  }
  if (cur.length) chunks.push(cur);
  return chunks;
}

// ---------- hosting config ----------
function hostingConfig() {
  if (!fs.existsSync(opt.config)) return {};
  try {
    let h = JSON.parse(fs.readFileSync(opt.config, 'utf8')).hosting || {};
    if (Array.isArray(h)) h = h.find((x) => x.site === opt.site || x.target === opt.site) || h[0] || {};
    const keys = ['rewrites', 'redirects', 'headers', 'cleanUrls', 'trailingSlashBehavior', 'appAssociation', 'i18n'];
    return Object.fromEntries(keys.filter((k) => h[k] !== undefined).map((k) => [k, h[k]]));
  } catch (e) {
    console.warn('Could not parse', opt.config, '-', e.message);
    return {};
  }
}

// ---------- upload one chunk ----------
async function uploadChunk(versionName, chunk, label) {
  const prepared = chunk.map((f) => {
    const gz = zlib.gzipSync(fs.readFileSync(f.abs));
    return { path: '/' + f.rel, gz, hash: crypto.createHash('sha256').update(gz).digest('hex') };
  });
  const files = Object.fromEntries(prepared.map((p) => [p.path, p.hash]));
  const pop = await json('POST', `${API}/${versionName}:populateFiles`, { files });
  const need = new Set(pop.uploadRequiredHashes || []);
  const byHash = new Map(prepared.map((p) => [p.hash, p]));
  const queue = [...need];
  let done = 0;
  await Promise.all(Array.from({ length: Math.min(opt.concurrency, queue.length) }, async () => {
    while (queue.length) {
      const h = queue.shift();
      await request(`${pop.uploadUrl}/${h}`, {
        method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: byHash.get(h).gz,
      });
      process.stdout.write(`\r  ${label}: uploaded ${++done}/${need.size} new files   `);
    }
  }));
  console.log(`\r  ${label}: ${prepared.length} files, ${need.size} uploaded, ${prepared.length - need.size} already on server   `);
}

// ---------- main ----------
(async () => {
  const root = path.resolve(opt.dir);
  if (!fs.existsSync(root)) throw new Error(`Directory not found: ${root}`);
  const files = walk(root, loadIgnore());
  const groups = groupByFolder(files);
  const total = files.reduce((s, f) => s + f.size, 0);
  console.log(`${files.length} files (${mb(total)}) in ${groups.length} folder group(s) after ignore rules.\n`);

  if (opt.dryRun) {
    for (const [name, fs_] of groups) {
      const sz = fs_.reduce((s, f) => s + f.size, 0);
      console.log(`${name}: ${fs_.length} files, ${mb(sz)}, ${chunkFiles(fs_).length} chunk(s)`);
    }
    return;
  }

  let state = {};
  if (opt.resume && fs.existsSync(opt.state)) state = JSON.parse(fs.readFileSync(opt.state, 'utf8'));
  const save = () => fs.writeFileSync(opt.state, JSON.stringify(state, null, 2));

  let versionName = state.site === opt.site ? state.versionName : null;
  if (versionName) console.log(`Resuming version ${versionName}`);
  else {
    const v = await json('POST', `${API}/sites/${opt.site}/versions`, { config: hostingConfig() });
    versionName = v.name;
    state = { site: opt.site, versionName };
    save();
    console.log(`Created version ${versionName}`);
  }

  let n = 0;
  for (const [name, folderFiles] of groups) {
    n++;
    const chunks = chunkFiles(folderFiles);
    console.log(`[${n}/${groups.length}] ${name} (${folderFiles.length} files, ${chunks.length} chunk(s))`);
    for (let i = 0; i < chunks.length; i++) {
      await uploadChunk(versionName, chunks[i], `chunk ${i + 1}/${chunks.length}`);
    }
  }

  console.log('\nFinalizing version...');
  await json('PATCH', `${API}/${versionName}?update_mask=status`, { status: 'FINALIZED' });

  console.log(`Releasing to "${opt.channel}"...`);
  const rel = await json('POST',
    `${API}/sites/${opt.site}/channels/${opt.channel}/releases?versionName=${encodeURIComponent(versionName)}`,
    { message: opt.message || 'chunked deploy' });
  if (fs.existsSync(opt.state)) fs.unlinkSync(opt.state);
  console.log(`Done. Release: ${rel.name}\nSite: https://${opt.site}.web.app`);
})().catch((e) => {
  console.error('\nFailed:', e.message);
  console.error(`Re-run with --resume to continue; files already uploaded are skipped.`);
  process.exit(1);
});
