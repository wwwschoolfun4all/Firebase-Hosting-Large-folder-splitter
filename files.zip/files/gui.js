#!/usr/bin/env node
/**
 * Local GUI for firebase-chunk-deploy (Firebase Hosting).
 * Run: node gui.js   -> opens http://localhost:4173
 * Binds to 127.0.0.1 only; runs deploy.js and streams its output to the page.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

const PORT = Number(process.env.PORT) || 4173;
const IGNORE = path.join(__dirname, '.firebaseignore');
let proc = null;

const send = (res, code, body, type = 'application/json') => {
  res.writeHead(code, { 'Content-Type': type });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
};
const readBody = (req) => new Promise((resolve) => {
  let s = '';
  req.on('data', (c) => (s += c));
  req.on('end', () => { try { resolve(JSON.parse(s || '{}')); } catch { resolve({}); } });
});

function buildArgs(b) {
  const args = [path.join(__dirname, 'deploy.js')];
  if (!/^[a-z0-9-]+$/i.test(b.site || '')) throw new Error('Enter a valid Hosting site ID.');
  args.push('--site', b.site);
  if (!b.dir || !fs.existsSync(b.dir)) throw new Error('Choose a folder that exists.');
  args.push('--dir', path.resolve(b.dir));
  if (b.channel) args.push('--channel', String(b.channel));
  for (const [flag, key] of [['--chunk-mb', 'chunkMb'], ['--max-files', 'maxFiles'], ['--concurrency', 'concurrency']]) {
    const n = Number(b[key]);
    if (n > 0) args.push(flag, String(n));
  }
  if (b.config) args.push('--config', path.resolve(b.config));
  if (b.message) args.push('--message', String(b.message));
  args.push('--ignore', IGNORE);
  if (b.resume) args.push('--resume');
  if (b.dryRun) args.push('--dry-run');
  return args;
}

const server = http.createServer(async (req, res) => {
  if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(req.headers.host || '')) return send(res, 403, { error: 'forbidden' });
  const url = new URL(req.url, 'http://localhost');

  if (req.method === 'GET' && url.pathname === '/') {
    return send(res, 200, fs.readFileSync(path.join(__dirname, 'gui.html')), 'text/html; charset=utf-8');
  }

  if (req.method === 'GET' && url.pathname === '/api/roots') {
    const out = [{ name: 'Home', path: os.homedir() }];
    const addChildren = (base, label) => {
      try {
        for (const d of fs.readdirSync(base, { withFileTypes: true })) {
          if (d.isDirectory() || d.isSymbolicLink()) out.push({ name: `${label}${d.name}`, path: path.join(base, d.name) });
        }
      } catch {}
    };
    if (process.platform === 'win32') {
      for (const l of 'CDEFGHIJKLMNOPQRSTUVWXYZ') {
        const p = `${l}:\\`;
        try { if (fs.existsSync(p)) out.push({ name: `Drive ${l}:`, path: p }); } catch {}
      }
    } else if (process.platform === 'darwin') {
      addChildren('/Volumes', 'USB/Volume: ');
    } else {
      const u = os.userInfo().username;
      addChildren(`/media/${u}`, 'USB/Media: ');
      addChildren(`/run/media/${u}`, 'USB/Media: ');
      addChildren('/mnt', 'Mount: ');
    }
    return send(res, 200, { roots: out });
  }

  if (req.method === 'GET' && url.pathname === '/api/ls') {
    const p = path.resolve(url.searchParams.get('path') || os.homedir());
    try {
      const dirs = fs.readdirSync(p, { withFileTypes: true })
        .filter((d) => d.isDirectory() && !d.name.startsWith('.'))
        .map((d) => d.name).sort((a, b) => a.localeCompare(b));
      const fileCount = fs.readdirSync(p, { withFileTypes: true }).filter((d) => d.isFile()).length;
      return send(res, 200, { path: p, parent: path.dirname(p), dirs, fileCount });
    } catch (e) { return send(res, 400, { error: e.message }); }
  }

  if (url.pathname === '/api/ignore') {
    if (req.method === 'GET') return send(res, 200, { text: fs.existsSync(IGNORE) ? fs.readFileSync(IGNORE, 'utf8') : '' });
    const b = await readBody(req);
    fs.writeFileSync(IGNORE, String(b.text || ''));
    return send(res, 200, { ok: true });
  }

  if (req.method === 'POST' && url.pathname === '/api/run') {
    if (proc) return send(res, 409, { error: 'A deploy is already running.' });
    let args;
    try { args = buildArgs(await readBody(req)); } catch (e) { return send(res, 400, { error: e.message }); }
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache' });
    proc = spawn(process.execPath, args, { cwd: __dirname });
    proc.stdout.on('data', (d) => res.write(d));
    proc.stderr.on('data', (d) => res.write(d));
    proc.on('error', (e) => res.write('\nCould not start: ' + e.message));
    proc.on('close', (code) => { res.end('\n[exit ' + code + ']'); proc = null; });
    return;
  }

  if (req.method === 'POST' && url.pathname === '/api/stop') {
    if (proc) proc.kill();
    return send(res, 200, { ok: true });
  }

  send(res, 404, { error: 'not found' });
});

server.listen(PORT, '127.0.0.1', () => {
  const addr = `http://localhost:${PORT}`;
  console.log(`Firebase Chunk Deploy GUI running at ${addr}  (Ctrl+C to quit)`);
  if (process.env.NO_OPEN) return;
  const cmd = process.platform === 'darwin' ? ['open', [addr]]
    : process.platform === 'win32' ? ['cmd', ['/c', 'start', '', addr]] : ['xdg-open', [addr]];
  try { spawn(cmd[0], cmd[1], { stdio: 'ignore', detached: true }).on('error', () => {}).unref(); } catch {}
});
